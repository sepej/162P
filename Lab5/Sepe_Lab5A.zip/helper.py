from student import *

# get an integer between min and max and validate
def get_integer(min_val, max_val):
    '''
    return integer
    '''
    

# get a name, check if not an empty string
def get_student_name():
    '''
    return name
    '''

# get a name and grade and create and return a Student
def create_student():
    '''
    student_name = get_student_name()
    student_grade = get_integer(1, 12)
    new_student = Student(student_name, student_grade)
    return new_student 
    '''

# selection sort, sort list of student objects by name
def sort_students_by_name(students):
    #loop for each student
    # compare name values
    # swap object locations in list
    '''
    print("")
    '''
